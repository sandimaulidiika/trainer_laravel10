@extends('layout.main')

@section('content')
    <div class="card">
        <div class="card-header">
            Welcome
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                Selamat datang di project pertama laravel 10
            </div>
        </div>
    </div>
@endsection
