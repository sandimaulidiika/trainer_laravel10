

<?php $__env->startSection('content'); ?>
    <h3>Data Students</h3>
    <div class="card">
        <div class="card-header">
            <a class="btn btn-sm btn-primary" onclick="window.location='<?php echo e(url('students/add')); ?>'">
                <i class="bi bi-plus-circle-fill"></i> Add New Students
            </a>
        </div>
        <div class="card-body">
            <?php if(session('msg')): ?>
                <div class="alert alert-success" role="alert">
                    <b>Berhasil! </b><?php echo e(session('msg')); ?>

                </div>
            <?php endif; ?>

            <table id="myTable" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Gender</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key->idstudent); ?></td>
                            <td><?php echo e($key->fullname); ?></td>
                            <td><?php echo e($key->gender == 'M' ? 'Male' : 'Female'); ?></td>
                            <td><?php echo e($key->email); ?></td>
                            <td><?php echo e($key->phone); ?></td>
                            <td>
                                <a href="<?php echo e(url('students/' . $key->idstudent)); ?>" class="btn btn-info" title="edit data">
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <form style="display: inline" action="<?php echo e(url('students/' . $key->idstudent)); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" title="hapus data"
                                        onclick="return deleteData('<?php echo e($key->fullname); ?>')">
                                        <i class="bi bi-trash-fill"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <script>
        function deleteData(name) {
            message = confirm(`Sure delete data name  ` + name + '?')
            if (message) {
                return true;
            } else {
                return false;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\belajar_laravel\resources\views/students/data.blade.php ENDPATH**/ ?>