

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Welcome
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                Selamat datang di project pertama laravel 10
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\belajar_laravel\resources\views/layout/home.blade.php ENDPATH**/ ?>